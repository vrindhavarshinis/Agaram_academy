a=int(input("Enter any amount:"))
b=int(input("Enter any rupees from(2000,500,200,100,50,20,10,5,1):"))
c=int(a/b)
if b==2000:
    print("No. of 2000 rupee notes is:", c)
elif b==500:
    print("No.of 500 rupee notes is:",c)
elif b==200:
    print("No.of 200 rupee notes is:",c)
elif b==100:
    print("No.of 100 rupee notes is:",c)
elif b==50:
    print("No.of 50 rupee notes is:",c)
elif b==20:
    print("No.of 20 rupee notes is:",c)
elif b==10:
    print("No.of 10 rupee notes is:",c)
elif b==5:
    print("No.of 5 rupee notes is:",c)
elif b==1:
    print("No.of 1 rupee notes is:",c)


