variable=input("Enter any character:")
if( variable>="a" and variable<="z")or(variable>="A"and variable<="Z"):
    print(variable, "is an Alphabet")
else:
    print(variable, "is not an Alphabet")
    