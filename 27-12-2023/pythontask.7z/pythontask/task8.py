variable=input("Enter any alphabet:")
if variable=="a"or variable=="A" or variable=="e" or variable=="E"or variable=="i" or variable=="I"or variable== "o" or variable=="O" or variable=="u" or variable=="U":
    print(variable, "is a Vowel")
else:
    print(variable,"is a consonant")