weeknumber=int(input("Enter week number(from 1-7):"))
if weeknumber==1:
    print("Sunday")
elif weeknumber==2:
    print("Monday")
elif weeknumber==3:
    print("Tuesday")
elif weeknumber==4:
    print("Wednesday")
elif weeknumber==5:
    print("Thursday")
elif weeknumber==6:
    print("Friday")
elif weeknumber==7:
    print("Saturday")