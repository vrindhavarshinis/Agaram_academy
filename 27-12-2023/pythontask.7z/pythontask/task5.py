number=int(input("Enter any Number:"))
if number%2==0:
    print(number, "is Even")
else:
    print(number,"is Odd")