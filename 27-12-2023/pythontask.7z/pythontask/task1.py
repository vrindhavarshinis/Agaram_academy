number_1=int(input("Enter Value 1:"))
number_2=int(input("Enter Value 2:"))
if number_1>number_2:
    print(number_1,"is Maximum")
elif number_2>number_1:
    print(number_2,"is Maximum")
else:
    print("Both values are Equal")
    