costprice=int(input("Enter Cost price of the product:"))
sellingprice=int(input("Enter Selling Price of the product"))
if sellingprice>costprice:
    print("Product solds for profit")
elif costprice>sellingprice:
    print("product solds for loss:")