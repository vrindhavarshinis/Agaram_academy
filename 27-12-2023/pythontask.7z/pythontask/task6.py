year=int(input("Enter any Year:"))
if year%4==0:
    print(year, "is a Leap Year")
else:
    print(year, "is not a Leap Year")