number=int(input("Enter any Number:"))
if number%5==0 and number%11==0:
    print(number,"is divisible by 5 and 11")
else:
    print(number,"is not divisible by both 5 and 11")