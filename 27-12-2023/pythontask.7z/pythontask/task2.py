value_1=int(input("Enter Value 1:"))
value_2=int(input("Enter Value 2:"))
value_3=int(input("Enter Value 3:"))
if value_1>value_2 and value_1>value_3:
    print(value_1, "is Maximum")
elif value_2>value_1 and value_2>value_3:
    print(value_2," is Maximum")
else:
    print(value_3,"is Maximum")
   