character=input("Enter any alphabet:")
if character>="a"and character<="z":
    print(character," is a Lowercase alphabet")
elif character>="A"and character<="Z":
    print(character, "is a Uppercase alphabet")