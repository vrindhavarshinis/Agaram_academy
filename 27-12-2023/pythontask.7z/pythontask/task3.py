number=int(input("Enter any Number:"))
if number<0:
    print(number, "is Negative Number")
elif number>0:
    print(number, "is Positive Number")
else:
    print(number,"is Zero")